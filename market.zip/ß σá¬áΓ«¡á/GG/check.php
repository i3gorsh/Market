<?


// Соединямся с БД
    $link=mysqli_connect("localhost", "root", "root", "testtable");

    $query = mysqli_query($link, "SELECT * FROM users LIMIT 1");
    $userdata = mysqli_fetch_assoc($query);



        print "Привет, ".$userdata['user_login'].". Всё работает!";

?>