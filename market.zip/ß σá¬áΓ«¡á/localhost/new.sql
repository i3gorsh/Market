CREATE TABLE `postav` (
    `user_id` int(11) unsigned NOT NULL auto_increment,
    `user_login` varchar(30) NOT NULL,
    `user_inn` varchar(29) NOT NULL,
    `user_number` varchar(50) NOT NULL,
    `prod` varchar(50) NOT NULL,
    `kol_vo` varchar(50) NOT NULL,
    `price` varchar(50) NOT NULL,
    PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;
